#include "game.h"

int main() {
    game mastermind;
    mastermind.playGame2();
    
    return 0;
}
